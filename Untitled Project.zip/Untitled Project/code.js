var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4dbd327b-1c4f-4f47-87a6-bf76f43d7a6a","6e1a3226-735e-4f7c-b047-111966c82398"],"propsByKey":{"4dbd327b-1c4f-4f47-87a6-bf76f43d7a6a":{"name":"niño","categories":["people"],"frameCount":1,"frameSize":{"x":123,"y":397},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-15 21:44:28 UTC","pngLastModified":"2021-01-15 21:44:28 UTC","version":"Y5N4Tt_21f8aWDAE9zR6K7n137NxqecC","sourceUrl":"assets/api/v1/animation-library/gamelab/Y5N4Tt_21f8aWDAE9zR6K7n137NxqecC/category_people/brown_sweater_hands_in_pockets.png","sourceSize":{"x":123,"y":397},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/Y5N4Tt_21f8aWDAE9zR6K7n137NxqecC/category_people/brown_sweater_hands_in_pockets.png"},"6e1a3226-735e-4f7c-b047-111966c82398":{"name":"money","categories":["board_games_and_cards"],"frameCount":6,"frameSize":{"x":86,"y":86},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-05 18:40:59 UTC","pngLastModified":"2021-01-05 18:43:23 UTC","version":"RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY","sourceUrl":"assets/api/v1/animation-library/gamelab/RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY/category_board_games_and_cards/bronze.png","sourceSize":{"x":516,"y":86},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/RTJET6.nqd4s3Krg4TQzqywTrzJpWoaY/category_board_games_and_cards/bronze.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var boy = createSprite(200, 200);

  boy.setAnimation("niño");
  boy.scale=0.4;
  
  var tesoro = createSprite(100, 100);
  tesoro.setAnimation("money");
  tesoro.scale=0.5;
  
var tesoro2 = createSprite(300, 50);
    tesoro2.setAnimation("money");
    tesoro2.scale=0.5;
  
 drawSprites();
 
 if (keyDown("space")) {
   boy.velocityX=1;
   
 }
 
 
 
 
 
 drawnet();
  
  if(line.x<0 || line.x>400)
  {
   
  }
    
  
  


function drawnet()
{  
  for(var num=0;num<400;num=num+20)
  {
    line(200,num,200,num+10);
  }
}


  


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
